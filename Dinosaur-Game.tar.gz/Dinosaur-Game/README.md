This is a remake of the Offline Dinosaur Game by chboo1
